import random
import time

start = time.time()

def printMatrix(matr):
	for i in matr:
		print(i)
	print("\n")

def randomMatrix(row, column, range_from, range_to):

	return [[random.randint(range_from, range_to) for _ in range(column)] for _ in range(row)] #creating matrix with random integer for each element

def sliceMatrix(matrix, srow, erow, scol, ecol):

	if srow > len(matrix) or srow < 0 or scol > len(matrix[0]) or scol < 0:
		print("\nStarting point is out of range\n")
	elif erow > len(matrix) or erow < 0 or ecol > len(matrix[0]) or ecol < 0:
		print("\nEnd point is out of range\n")
	else:
		return [row[scol:ecol] for row in matrix[srow:erow]]

row0 = int(input("enter row size for original matrix: "))
col0 = int(input("enter column size for original: "))
original = randomMatrix(int(row0), int(col0), 0, 10)
printMatrix(original)

row1 = int(input("enter start row: "))
row2 = int(input("enter end row: "))
col1 = int(input("enter start column: "))
col2 = int(input("enter end column: "))
result = sliceMatrix(original, int(row1), int(row2), int(col1), int(col2))
printMatrix(result)