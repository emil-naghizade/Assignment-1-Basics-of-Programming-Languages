import random
import time

start = time.time()

def multiplyMatrix(matrix1, matrix2):

	if len(matrix1[0])!= len(matrix2):
		print("Matrix sizes are not correct. Matrix multiplication is impossible!")
		result = [[-1 for _ in range(len(matrix2[0]))] for _ in range(len(matrix1)) ]
	else:
		result = [[0 for _ in range(len(matrix2[0]))] for _ in range(len(matrix1)) ]

		for i in range(len(matrix1)) : # taking the rows of first matrix
			for j in range(len(matrix2[0])) : # taking the columns of first matrix
				for k in range(len(matrix1[0])) : # taking corresponding elements for performing sumproduct calculation
					result[i][j] += matrix1[i][k] * matrix2[k][j]
	
	return result

def printMatrix(matr):
	for i in matr:
		print(i)
	print("\n")

def randomMatrix(row, column, range_from, range_to):

	return [[random.randint(range_from, range_to) for _ in range(column)] for _ in range(row)] #creating matrix with random integer for each element

def inputMatrix():

	rows = int(input("Enter the row size: "))
	
	new_matrix = []

	for i in range(rows):
		input_row = input("Enter the values for row :" + str(i) + ": ") # input the row
		row = input_row.split() # split the row to list of string
		int_row = [int(r) for r in row] # convert the list to list of integer
		new_matrix.append(int_row)

	return new_matrix

#Test case with given matrices

print("Test case 1 with given matrices: \n")
Mat1 = [[7,8,9],[4,5,6],[1,2,3],[9,6,3],[8,5,2]]
Mat2 = [[10,1,4,7],[20,2,5,8],[30,3,6,9]]
printMatrix(Mat1)
printMatrix(Mat2)

print("Matrix 1 * Matrix 2: \n")
Res1 = multiplyMatrix(Mat1, Mat2)
printMatrix(Res1)

print("Matrix 2 * Matrix 1: \n")
Res2 = multiplyMatrix(Mat2, Mat1)
printMatrix(Res2)


#Test case with random matrices
print("Test case with random matrices: \n")
row3 = int(input("enter row size for first matrix: "))
col3 = int(input("enter column size for first matrix: "))
Mat3 = randomMatrix(row3, col3, 0, 50)
printMatrix(Mat3)

row4 = int(input("enter row size for first matrix: "))
col4 = int(input("enter column size for first matrix: "))
Mat4 = randomMatrix(row4, col4, 0, 50)
printMatrix(Mat4)

print("Matrix 1 * Matrix 2: \n")
Res3 = multiplyMatrix(Mat3, Mat4)
printMatrix(Res3)

print("Matrix 2 * Matrix 1: \n")
Res4 = multiplyMatrix(Mat4, Mat3)
printMatrix(Res4)


# Test case with user input
print("Test case with random matrices: \n")
test=input("enter number of test cases: ")
for i in range(int(test)):
	Mat5=inputMatrix()
	print("Matrix 1: \n")
	printMatrix(Mat5)

	Mat6=inputMatrix()
	print("Matrix 2: \n")
	printMatrix(Mat6)

	print("Matrix 1 * Matrix 2: \n")
	Res5 = multiplyMatrix(Mat5, Mat6)
	printMatrix(Res5)

	print("Matrix 2 * Matrix 1: \n")
	Res6 = multiplyMatrix(Mat6, Mat5)
	printMatrix(Res6)


finish = time.time()
elapsed = finish - start
print("Elapsed time: " + str(elapsed) + "seconds")
